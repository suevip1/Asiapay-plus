import { printANSI } from '@/utils/screenLog'

export default function Initializer () {
  printANSI() // 请自行移除该行.  please remove this line
  // last step
}
