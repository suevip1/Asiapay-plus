import HttpRequest from '@/http/HttpRequest'

const request = new HttpRequest()
export default request
